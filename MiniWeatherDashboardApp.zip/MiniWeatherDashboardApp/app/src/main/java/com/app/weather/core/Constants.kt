package com.app.weather.core

object Constants {
    const val WEATHER_API_KEY = "895fa8416f8fbc4f8049c8e52c20759b"
    const val NETWORK_TIME_OUT = 30L
}